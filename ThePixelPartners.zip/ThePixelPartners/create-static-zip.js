// create-static-zip.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';
import AdmZip from 'adm-zip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define directories
const staticDir = path.join(__dirname, 'static');
const zipOutputPath = path.join(__dirname, 'the-pixel-partners-static.zip');

// Check if the static directory exists
if (!fs.existsSync(staticDir)) {
  console.error('Static directory not found. Run "node build-static.js" first to generate the static files.');
  process.exit(1);
}

// Inform the user
console.log('Preparing to create a zip file of the static website...');

// Create the zip file
try {
  // Check if a previous zip file exists and ask for confirmation to overwrite
  if (fs.existsSync(zipOutputPath)) {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question(`The file ${zipOutputPath} already exists. Overwrite? (y/n) `, (answer) => {
      if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
        createZip();
      } else {
        console.log('Operation cancelled. Zip file was not created.');
      }
      rl.close();
    });
  } else {
    createZip();
  }
} catch (error) {
  console.error('Error creating zip file:', error);
  process.exit(1);
}

function createZip() {
  try {
    // Delete the existing zip file if it exists
    if (fs.existsSync(zipOutputPath)) {
      fs.unlinkSync(zipOutputPath);
    }

    console.log('Creating zip file...');
    
    // Use adm-zip to create the archive
    const zip = new AdmZip();
    
    // Add the entire static directory to the zip
    addDirectoryToZip(zip, staticDir, '');
    
    // Write the zip file
    zip.writeZip(zipOutputPath);
    
    console.log(`\nStatic website has been successfully zipped to: ${zipOutputPath}`);
    console.log('You can download this file and upload it to any static web hosting service.');
  } catch (error) {
    console.error('Error during zip creation:', error);
    process.exit(1);
  }
}

// Helper function to recursively add directory contents to zip
function addDirectoryToZip(zip, directory, zipPath) {
  const files = fs.readdirSync(directory);
  
  for (const file of files) {
    const filePath = path.join(directory, file);
    const zipFilePath = path.join(zipPath, file);
    
    if (fs.statSync(filePath).isDirectory()) {
      addDirectoryToZip(zip, filePath, zipFilePath);
    } else {
      zip.addLocalFile(filePath, path.dirname(zipFilePath));
    }
  }
}