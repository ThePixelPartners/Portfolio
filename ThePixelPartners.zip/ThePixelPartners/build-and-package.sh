#!/bin/bash
# Script to build and package the static website

echo "=== Step 1: Building static website ==="
node build-static.js

if [ $? -ne 0 ]; then
  echo "Error: Static build failed. Aborting."
  exit 1
fi

echo ""
echo "=== Step 2: Creating zip archive ==="
# Skip interactive prompt by passing 'y' to the script
echo "y" | node create-static-zip.js

if [ $? -ne 0 ]; then
  echo "Warning: Creating zip archive failed, but static files are still available."
else
  echo "Zip archive created successfully."
fi

echo ""
echo "=== Complete ==="
echo "Static website has been built and packaged."
echo "You can find the static files in the 'static' directory"
if [ -f "the-pixel-partners-static.zip" ]; then
  echo "and the zip archive in 'the-pixel-partners-static.zip'."
fi

echo ""
echo "=== Deployment Instructions ==="
echo "For detailed deployment instructions, see:"
echo "1. STATIC_DEPLOYMENT.md - Markdown format"
echo "2. static/README.html - Browser-viewable format"