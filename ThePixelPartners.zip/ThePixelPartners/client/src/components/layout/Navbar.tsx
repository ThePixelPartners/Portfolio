import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { NAVIGATION_LINKS } from "@/lib/constants";
import { smoothScrollTo } from "@/lib/utils";
import { useScrollPosition } from "@/lib/hooks";
import { Menu, X } from "lucide-react";
import FullLogo from "@/assets/FullLogo.jpg";

export default function Navbar() {
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const scrollY = useScrollPosition();
  const isShadow = scrollY > 10;

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleNavLinkClick = (href: string) => {
    if (href.startsWith('#')) {
      const id = href.replace('#', '');
      // Check if we're already on the home page
      const currentPath = window.location.pathname;
      if (currentPath === '/' || currentPath === '') {
        // If on home page, just scroll to the section
        smoothScrollTo(id);
      } else {
        // If on another page, navigate to home and then scroll
        setLocation('/');
        // Need a small delay to allow the navigation to complete
        setTimeout(() => {
          smoothScrollTo(id);
        }, 100);
      }
    } else {
      // For non-hash links like /articles, navigate directly to the page and scroll to top
      setLocation(href);
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 50);
    }
    setMobileMenuOpen(false);
  };

  // Close mobile menu when resizing to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024 && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [mobileMenuOpen]);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${isShadow ? 'backdrop-blur-md bg-black/80 border-b border-white/10' : 'bg-transparent'}`}>
      <div className="airsculpt-container">
        <nav className="flex justify-between items-center h-20">
          <a 
            href="/" 
            className="flex items-center" 
            onClick={(e) => { 
              e.preventDefault(); 
              setLocation('/');
            }}
          >
            <img src={FullLogo} alt="The Pixel Partners Logo" className="h-12" />
          </a>
          
          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-10">
            {NAVIGATION_LINKS.map((link, index) => (
              <a 
                key={index} 
                href={link.href} 
                className="text-white font-medium hover:text-primary transition-colors"
                onClick={(e) => { e.preventDefault(); handleNavLinkClick(link.href); }}
              >
                {link.label}
              </a>
            ))}
            
            {/* Removed duplicate link (now included in NAVIGATION_LINKS) */}
            
            {/* CTA Button */}
            <a 
              href="#contact" 
              className="airsculpt-button-primary"
              onClick={(e) => { e.preventDefault(); handleNavLinkClick('#contact'); }}
            >
              Get Started
            </a>
          </div>
          
          {/* Mobile Navigation Button */}
          <button 
            className="lg:hidden text-white p-2 hover:text-primary focus:outline-none"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={`${mobileMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0'} 
                    lg:hidden bg-black/95 backdrop-blur-md overflow-hidden absolute w-full left-0 right-0 z-40 transition-all duration-300`}
      >
        <div className="airsculpt-container py-4 flex flex-col space-y-4">
          {NAVIGATION_LINKS.map((link, index) => (
            <a 
              key={index} 
              href={link.href} 
              className="text-white py-3 px-4 hover:bg-white/5 rounded-md transition-colors"
              onClick={(e) => { e.preventDefault(); handleNavLinkClick(link.href); }}
            >
              {link.label}
            </a>
          ))}
          {/* Removed duplicate link (now included in NAVIGATION_LINKS) */}
          <div className="pt-2 pb-6 px-4">
            <a 
              href="#contact" 
              className="airsculpt-button-primary w-full text-center"
              onClick={(e) => { e.preventDefault(); handleNavLinkClick('#contact'); }}
            >
              Get Started
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
