import { NAVIGATION_LINKS } from "@/lib/constants";
import { smoothScrollTo } from "@/lib/utils";
import FullLogo from "@/assets/FullLogo.jpg";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Footer() {
  const [, setLocation] = useLocation();
  
  const handleNavLinkClick = (href: string) => {
    if (href.startsWith('#')) {
      const id = href.replace('#', '');
      // Check if we're already on the home page
      const currentPath = window.location.pathname;
      if (currentPath === '/' || currentPath === '') {
        // If on home page, just scroll to the section
        smoothScrollTo(id);
      } else {
        // If on another page, navigate to home and then scroll
        setLocation('/');
        // Need a small delay to allow the navigation to complete
        setTimeout(() => {
          smoothScrollTo(id);
        }, 100);
      }
    } else {
      // For non-hash links like /articles, navigate directly to the page and scroll to top
      setLocation(href);
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 50);
    }
  };

  return (
    <footer className="bg-text text-white">
      {/* Footer Top Section with CTA */}
      <div className="bg-gradient-to-r from-primary to-primary-light">
        <div className="airsculpt-container py-16">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="lg:w-1/2">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Your Digital Presence?</h2>
              <p className="text-white/90 text-lg mb-0 max-w-md">
                Let's create something amazing together. Schedule a free consultation today.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#contact" 
                className="airsculpt-button bg-white text-primary hover:bg-white/90 flex items-center gap-2 group"
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('#contact'); }}
              >
                Get Started
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Footer Section */}
      <div className="airsculpt-container pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12 mb-16">
          {/* Column 1: Logo & About */}
          <div>
            <a 
              href="/" 
              className="block mb-6"
              onClick={(e) => { 
                e.preventDefault(); 
                setLocation('/');
              }}
            >
              <img src={FullLogo} alt="The Pixel Partners Logo" className="h-12" />
            </a>
            <p className="text-white/80 mb-6">Professional web development services delivered by a passionate husband-and-wife team dedicated to helping businesses succeed online.</p>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/profile.php?id=61574670937513" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-primary transition-colors p-2 border border-white/20 rounded-full">
                <Facebook size={16} />
              </a>
              <a href="https://www.instagram.com/thepixelpartners?igsh=MXZkdTE4YWxqcmQ3Zw==" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-primary transition-colors p-2 border border-white/20 rounded-full">
                <Instagram size={16} />
              </a>
              <a href="https://www.linkedin.com/in/the-pixel-partners-a06361359/" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-primary transition-colors p-2 border border-white/20 rounded-full">
                <Linkedin size={16} />
              </a>
            </div>
          </div>
          
          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-4">
              {NAVIGATION_LINKS.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                    onClick={(e) => { e.preventDefault(); handleNavLinkClick(link.href); }}
                  >
                    <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Column 3: Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Our Services</h3>
            <ul className="space-y-4">
              <li>
                <a 
                  href="#"
                  className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    setLocation('/service/0');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                  Web Design & UX/UI
                </a>
              </li>
              <li>
                <a 
                  href="#"
                  className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    setLocation('/service/1');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                  Front-End Development
                </a>
              </li>
              <li>
                <a 
                  href="#"
                  className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    setLocation('/service/2');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                  Back-End Development
                </a>
              </li>
              <li>
                <a 
                  href="#"
                  className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    setLocation('/service/3');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                  E-Commerce Solutions
                </a>
              </li>
              <li>
                <a 
                  href="#"
                  className="text-white/70 hover:text-primary transition-colors flex items-center gap-2 group"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    setLocation('/services');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                  View All Services
                </a>
              </li>
            </ul>
          </div>
          
          {/* Column 4: Contact Info & Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Us</h3>
            <div className="space-y-4 mb-6">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary mt-1" />
                <p className="text-white/70">Spanish Fork, UT</p>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-primary mt-1" />
                <p className="text-white/70">(801) 380-8746</p>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-primary mt-1" />
                <p className="text-white/70">
                  <a 
                    href="mailto:hello@thepixelpartners.com" 
                    className="hover:text-primary transition-colors"
                  >
                    hello@thepixelpartners.com
                  </a>
                </p>
              </div>
            </div>
            

          </div>
        </div>
        
        {/* Copyright Section */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/50 text-sm">&copy; {new Date().getFullYear()} The Pixel Partners. All rights reserved.</p>
            <div className="flex flex-wrap gap-6">
              <a href="#" className="text-white/50 hover:text-primary text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-white/50 hover:text-primary text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-white/50 hover:text-primary text-sm transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
