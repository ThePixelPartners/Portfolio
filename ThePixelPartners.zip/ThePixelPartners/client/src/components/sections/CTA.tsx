import { useRef } from "react";
import { smoothScrollTo } from "@/lib/utils";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";

export default function CTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);

  const handleButtonClick = (href: string) => {
    const id = href.replace('#', '');
    smoothScrollTo(id);
  };

  return (
    <section className="py-16 bg-gradient-primary text-white" ref={sectionRef}>
      <div className="container mx-auto px-4 text-center">
        <motion.h2 
          className="font-poppins font-bold text-3xl md:text-4xl mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          Ready to Start Your Next Project?
        </motion.h2>
        <motion.p 
          className="max-w-2xl mx-auto mb-8 text-gray-200"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Let's create something amazing together. Our team is ready to bring your vision to life.
        </motion.p>
        <motion.div 
          className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <a 
            href="#contact" 
            className="bg-gradient-accent hover:bg-white hover:text-primary text-white font-poppins font-medium px-8 py-3 rounded-full transition-all duration-300"
            onClick={(e) => { e.preventDefault(); handleButtonClick('#contact'); }}
          >
            Get Started Now
          </a>
          <a 
            href="#services" 
            className="border-2 border-white text-white hover:bg-white hover:text-primary font-poppins font-medium px-8 py-3 rounded-full transition-all duration-300"
            onClick={(e) => { e.preventDefault(); handleButtonClick('#services'); }}
          >
            Explore Services
          </a>
        </motion.div>
      </div>
    </section>
  );
}
