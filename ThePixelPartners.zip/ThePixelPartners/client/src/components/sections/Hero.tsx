import { smoothScrollTo } from "@/lib/utils";
import { motion } from "framer-motion";
import FullLogo from "@/assets/FullLogo.jpg";
import { ArrowRight, CheckCircle, Code, Palette, Globe } from "lucide-react";

export default function Hero() {
  const handleButtonClick = (href: string) => {
    const id = href.replace('#', '');
    smoothScrollTo(id);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5 } }
  };

  const logoVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.8,
        delay: 0.2,
        ease: "easeOut"
      } 
    }
  };

  return (
    <section id="home" className="pt-16 pb-24 md:pt-20 md:pb-32 bg-bgColor relative overflow-hidden">
      {/* Gradient overlays for visual effect */}
      <div className="absolute top-0 left-0 w-1/3 h-96 bg-primary/10 blur-[100px] rounded-full"></div>
      <div className="absolute bottom-0 right-0 w-1/3 h-96 bg-accent/10 blur-[100px] rounded-full"></div>
      
      <div className="airsculpt-container relative z-10">
        {/* Logo as Central Feature */}
        <motion.div 
          className="flex justify-center mb-16"
          variants={logoVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="relative">
            <div className="absolute -inset-3 bg-gradient-brand opacity-30 blur-md rounded-full"></div>
            <img 
              src={FullLogo} 
              alt="The Pixel Partners Logo" 
              className="relative w-64 h-auto rounded-full shadow-xl"
            />
          </div>
        </motion.div>
        
        {/* Main Heading */}
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.h1 
            className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
            variants={itemVariants}
          >
            <span className="text-primary-gradient">The Pixel Partners</span> <br />
            <span className="text-white">Web Development Team</span>
          </motion.h1>
          
          <motion.p 
            className="text-white/80 text-lg mb-10 max-w-2xl mx-auto"
            variants={itemVariants}
          >
            We're a husband and wife web development team passionate about creating beautiful, 
            functional websites that help businesses grow. With over a decade of combined experience, 
            we bring a personal touch to every project.
          </motion.p>
          
          <motion.div 
            className="flex justify-center mb-16"
            variants={itemVariants}
          >
            <a 
              href="#contact" 
              className="airsculpt-button-primary flex items-center justify-center gap-2 group"
              onClick={(e) => { e.preventDefault(); handleButtonClick('#contact'); }}
            >
              Work With Us
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </motion.div>
        </motion.div>
        
        {/* Trust Elements */}
        <motion.div 
          className="flex justify-center mb-20"
          variants={itemVariants}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="flex flex-wrap justify-center gap-8">
            <div className="flex items-center gap-2">
              <CheckCircle className="text-primary w-5 h-5" />
              <span className="text-white/70">SEO-Optimized Solutions</span>
            </div>
          </div>
        </motion.div>
        
        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl transition-all duration-300 hover:bg-white/10 group"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center mb-6 transition-all duration-300 group-hover:bg-primary/30">
              <Palette className="text-primary w-7 h-7" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-white">Web Design</h3>
            <p className="text-white/70 mb-4">Beautiful, responsive designs that look great on all devices. We create intuitive user experiences that convert visitors into customers.</p>
            <a 
              href="#services" 
              className="text-primary flex items-center gap-1 text-sm font-medium group-hover:underline"
              onClick={(e) => { e.preventDefault(); handleButtonClick('#services'); }}
            >
              Learn More
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </motion.div>
          
          <motion.div 
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl transition-all duration-300 hover:bg-white/10 group"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center mb-6 transition-all duration-300 group-hover:bg-primary/30">
              <Code className="text-primary w-7 h-7" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-white">Development</h3>
            <p className="text-white/70 mb-4">Clean, efficient code that powers fast-loading websites. We build custom solutions that integrate with your existing systems.</p>
            <a 
              href="#services" 
              className="text-primary flex items-center gap-1 text-sm font-medium group-hover:underline"
              onClick={(e) => { e.preventDefault(); handleButtonClick('#services'); }}
            >
              Learn More
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </motion.div>
          
          <motion.div 
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl transition-all duration-300 hover:bg-white/10 group"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
          >
            <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center mb-6 transition-all duration-300 group-hover:bg-primary/30">
              <Globe className="text-primary w-7 h-7" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-white">E-Commerce</h3>
            <p className="text-white/70 mb-4">Secure, scalable online stores that drive sales. We build custom shopping experiences that make managing your products easy.</p>
            <a 
              href="#services" 
              className="text-primary flex items-center gap-1 text-sm font-medium group-hover:underline"
              onClick={(e) => { e.preventDefault(); handleButtonClick('#services'); }}
            >
              Learn More
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
