import { useRef } from "react";
import { SERVICES } from "@/lib/constants";
import { smoothScrollTo } from "@/lib/utils";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";
import { Check, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);
  const [, setLocation] = useLocation();

  const handleButtonClick = (href: string) => {
    const id = href.replace('#', '');
    smoothScrollTo(id);
  };

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="services" className="airsculpt-section bg-bgColor relative overflow-hidden" ref={sectionRef}>
      {/* Gradient overlay for visual effect */}
      <div className="absolute bottom-0 left-0 w-1/3 h-96 bg-accent/5 blur-[100px] rounded-full"></div>
      
      <div className="airsculpt-container">
        <motion.div 
          className="text-center mb-16"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={fadeInUp}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our <span className="text-primary-gradient">Services</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-accent mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-white/70">
            Comprehensive web solutions tailored to your specific needs, from design to development and beyond.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service, index) => (
            <motion.div 
              key={index}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:bg-white/10"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
            >
              <div className="bg-gradient-primary p-6 flex justify-center">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                  <i className={`${service.icon} text-2xl text-white`}></i>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-semibold text-xl mb-3 text-white">{service.title}</h3>
                <p className="text-white/70 mb-4">{service.description}</p>
                <ul className="text-sm text-white/70 space-y-3 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="text-accent w-4 h-4 mt-1 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button 
                  className="text-primary font-medium hover:text-accent transition-colors flex items-center gap-2 group"
                  onClick={() => {
                    setLocation(`/service/${index}`);
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  Learn More
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-16 flex flex-col sm:flex-row items-center justify-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <button 
            className="airsculpt-button-primary"
            onClick={() => {
              setLocation("/services");
              setTimeout(() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }, 50);
            }}
          >
            View All Services
          </button>
          
          <a 
            href="#contact" 
            className="airsculpt-button-secondary"
            onClick={(e) => { e.preventDefault(); handleButtonClick('#contact'); }}
          >
            Get Started Today
          </a>
        </motion.div>
      </div>
    </section>
  );
}
