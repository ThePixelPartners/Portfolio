import { useRef, useState } from "react";
import { PORTFOLIO_ITEMS } from "@/lib/constants";
import { smoothScrollTo } from "@/lib/utils";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function Portfolio() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);
  const [activeFilter, setActiveFilter] = useState('all');

  const handleButtonClick = (href: string) => {
    const id = href.replace('#', '');
    smoothScrollTo(id);
  };

  const filterPortfolio = (category: string) => {
    setActiveFilter(category);
  };

  const filteredItems = activeFilter === 'all' 
    ? PORTFOLIO_ITEMS 
    : PORTFOLIO_ITEMS.filter(item => item.category === activeFilter);

  return (
    <section id="portfolio" className="airsculpt-section bg-bgColor relative overflow-hidden" ref={sectionRef}>
      {/* Gradient overlay for visual effect */}
      <div className="absolute top-0 right-0 w-1/3 h-96 bg-primary/5 blur-[100px] rounded-full"></div>
      
      <div className="airsculpt-container">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our <span className="text-primary-gradient">Portfolio</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-accent mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-white/70">
            Browse our recent projects and see how we've helped businesses achieve their digital goals.
          </p>
        </motion.div>
        
        {/* Portfolio Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${activeFilter === 'all' ? 'bg-gradient-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
            onClick={() => filterPortfolio('all')}
          >
            All Projects
          </button>
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${activeFilter === 'ecommerce' ? 'bg-gradient-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
            onClick={() => filterPortfolio('ecommerce')}
          >
            E-Commerce
          </button>
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${activeFilter === 'corporate' ? 'bg-gradient-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
            onClick={() => filterPortfolio('corporate')}
          >
            Corporate
          </button>
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${activeFilter === 'custom' ? 'bg-gradient-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
            onClick={() => filterPortfolio('custom')}
          >
            Custom Development
          </button>
        </motion.div>
        
        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <motion.div 
              key={index}
              className="group"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
              layout
            >
              <div className="relative overflow-hidden rounded-2xl shadow-lg bg-white/5 border border-white/10">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-primary/80 to-transparent opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex items-end">
                  <div className="p-6">
                    <h3 className="font-semibold text-xl text-white mb-2">{item.title}</h3>
                    <p className="text-white text-sm mb-4">{item.description}</p>
                    <a 
                      href="#" 
                      className="text-white border border-white px-4 py-2 rounded-full text-sm hover:bg-white hover:text-primary transition-colors inline-flex items-center gap-2 group"
                    >
                      View Details
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <a 
            href="#contact" 
            className="airsculpt-button-primary flex items-center gap-2 mx-auto inline-flex"
            onClick={(e) => { e.preventDefault(); handleButtonClick('#contact'); }}
          >
            Start Your Project
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
