import { useRef, useState } from "react";
import { useIsInViewport } from "@/lib/hooks";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

type ContactFormData = {
  name: string;
  email: string;
  subject: string;
  budget: string;
  message: string;
};

export default function Contact() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    subject: '',
    budget: '',
    message: ''
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      // For static site deployment: In a real application, this would send to a server
      // For now, we'll simulate a success response after a short delay
      return new Promise<Response>((resolve) => {
        setTimeout(() => {
          console.log('Contact form submission (static):', data);
          // Create a mock response
          const response = new Response(
            JSON.stringify({
              message: 'Contact form submitted successfully',
              data: { name: data.name, email: data.email, subject: data.subject, budget: data.budget }
            }),
            { status: 200, headers: { 'Content-Type': 'application/json' } }
          );
          resolve(response);
        }, 800); // Simulate network delay
      });
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "We'll get back to you as soon as possible.",
        variant: "default",
      });
      setFormData({
        name: '',
        email: '',
        subject: '',
        budget: '',
        message: ''
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to send message: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  return (
    <section id="contact" className="py-20 bg-gray-light" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-4 text-gradient">Contact Us</h2>
          <div className="w-20 h-1 bg-gradient-accent mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-dark">Ready to get started? Reach out to us for a free consultation about your project.</p>
        </motion.div>
        
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Contact Form */}
          <motion.div 
            className="lg:w-2/3 bg-white rounded-lg shadow-lg p-8"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="font-poppins font-semibold text-2xl text-black mb-6">Get in Touch</h3>
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-black mb-2 font-medium">Your Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-black" 
                    placeholder="" 
                    required 
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-black mb-2 font-medium">Email Address</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-black" 
                    placeholder="" 
                    required 
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="subject" className="block text-black mb-2 font-medium">Subject</label>
                <input 
                  type="text" 
                  id="subject" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-black" 
                  placeholder=""
                  value={formData.subject}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="budget" className="block text-black mb-2 font-medium">Budget Range</label>
                <select 
                  id="budget" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-black"
                  value={formData.budget}
                  onChange={handleInputChange}
                >
                  <option value="">Select a range</option>
                  <option value="1000-3000">$1,000 - $3,000</option>
                  <option value="3000-5000">$3,000 - $5,000</option>
                  <option value="5000-10000">$5,000 - $10,000</option>
                  <option value="10000+">$10,000+</option>
                </select>
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-black mb-2 font-medium">Project Details</label>
                <textarea 
                  id="message" 
                  rows={5} 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-black" 
                  placeholder=""
                  value={formData.message}
                  onChange={handleInputChange}
                ></textarea>
              </div>
              
              <button 
                type="submit" 
                className="bg-gradient-accent hover:bg-[var(--color-accent)] text-white font-poppins font-medium px-8 py-3 rounded-full transition-all duration-300 w-full md:w-auto disabled:opacity-70"
                disabled={contactMutation.isPending}
              >
                {contactMutation.isPending ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </motion.div>
          
          {/* Contact Info */}
          <motion.div 
            className="lg:w-1/3"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-gradient-primary text-white rounded-lg shadow-lg p-8 mb-8">
              <h3 className="font-poppins font-semibold text-2xl mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="text-accent text-xl mr-4 mt-1">
                    <i className="fas fa-envelope"></i>
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium mb-1">Email Us</h4>
                    <a href="mailto:hello@thepixelpartners.com" className="text-gray-200 hover:text-accent transition-colors">hello@thepixelpartners.com</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="text-accent text-xl mr-4 mt-1">
                    <i className="fas fa-phone-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium mb-1">Call Us</h4>
                    <a href="tel:+18013808746" className="text-gray-200 hover:text-accent transition-colors">(801) 380-8746</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="text-accent text-xl mr-4 mt-1">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium mb-1">Location</h4>
                    <p className="text-gray-200">Spanish Fork, UT</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h4 className="font-poppins font-medium mb-4">Follow Us</h4>
                <div className="flex space-x-4">
                  <a href="https://www.facebook.com/profile.php?id=61574670937513" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-gradient-accent w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300">
                    <i className="fab fa-facebook-f text-white"></i>
                  </a>
                  <a href="https://www.instagram.com/thepixelpartners?igsh=MXZkdTE4YWxqcmQ3Zw==" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-gradient-accent w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300">
                    <i className="fab fa-instagram text-white"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/the-pixel-partners-a06361359/" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-gradient-accent w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300">
                    <i className="fab fa-linkedin-in text-white"></i>
                  </a>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="font-poppins font-semibold text-xl text-primary mb-4">Business Hours</h3>
              <ul className="space-y-3 text-gray-800">
                <li className="flex justify-between">
                  <span className="font-medium">Monday - Friday:</span>
                  <span className="font-medium">8:00 AM - 5:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span className="font-medium">Saturday - Sunday:</span>
                  <span className="font-medium">Closed</span>
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
