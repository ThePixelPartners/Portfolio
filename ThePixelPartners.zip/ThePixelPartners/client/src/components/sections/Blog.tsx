import { useRef } from "react";
import { useLocation } from "wouter";
import { BLOG_POSTS } from "@/lib/constants";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";

export default function Blog() {
  const [, setLocation] = useLocation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);

  return (
    <section id="newsroom" className="py-20 bg-black" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-4 text-gradient">The Newsroom</h2>
          <div className="w-20 h-1 bg-gradient-accent mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-white/80">Insights, tips and trends from our experts to help you navigate the digital landscape.</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post, index) => (
            <motion.div 
              key={index}
              className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform duration-300 hover:-translate-y-2 text-gray-800 cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              onClick={() => {
                setLocation(`/article/${index}`);
                setTimeout(() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }, 50);
              }}
            >
              <div className="relative">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-48 object-cover"
                  onClick={(e) => {
                    e.stopPropagation();
                    setLocation(`/article/${index}`);
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                />
                <div className="absolute top-4 left-4 bg-gradient-accent text-white text-xs font-medium px-3 py-1 rounded-full">
                  {post.category}
                </div>
              </div>
              <div className="p-6">
                <h3 
                  className="font-poppins font-semibold text-xl mb-3 text-gray-900 cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    setLocation(`/article/${index}`);
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >{post.title}</h3>
                <p className="text-gray-800 mb-4 line-clamp-3">{post.excerpt}</p>
                <div className="flex items-start">
                  <img 
                    src={post.authorAvatar} 
                    alt={post.author} 
                    className="w-8 h-8 rounded-full mr-3 mt-1"
                  />
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-800">{post.author}</span>
                    <span className="text-xs text-gray-600 mt-1">{post.date}</span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setLocation(`/article/${index}`);
                        setTimeout(() => {
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }, 50);
                      }} 
                      className="mt-3 inline-block text-accent font-poppins font-medium hover:text-primary transition-colors cursor-pointer text-sm"
                    >
                      Read More <i className="fas fa-arrow-right ml-1"></i>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        

      </div>
    </section>
  );
}
