import { useRef } from "react";
import { TESTIMONIALS } from "@/lib/constants";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";

export default function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);

  const renderStars = (rating: number) => {
    return Array(rating).fill(0).map((_, index) => (
      <i key={index} className="fas fa-star"></i>
    ));
  };

  return (
    <section className="py-20 bg-black" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-4 text-gradient">Client Testimonials</h2>
          <div className="w-20 h-1 bg-gradient-accent mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-white/80">Hear what our clients have to say about working with us.</p>
        </motion.div>
        
        <div className="testimonial-slider relative">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial, index) => (
              <motion.div 
                key={index}
                className="bg-white p-6 rounded-lg shadow-lg transition-transform duration-300 hover:scale-102 text-gray-800"
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <div className="flex items-center mb-4">
                  <div className="text-accent mb-2">
                    {renderStars(testimonial.rating)}
                  </div>
                </div>
                <p className="text-gray-800 mb-6 italic">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name} 
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-poppins font-medium text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-800">{testimonial.position}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        

      </div>
    </section>
  );
}
