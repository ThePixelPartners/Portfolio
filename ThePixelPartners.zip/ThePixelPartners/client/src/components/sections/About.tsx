import { useRef } from "react";
import { smoothScrollTo } from "@/lib/utils";
import { useIsInViewport } from "@/lib/hooks";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight } from "lucide-react";

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useIsInViewport(sectionRef);

  const handleButtonClick = (href: string) => {
    const id = href.replace('#', '');
    smoothScrollTo(id);
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <section id="about" className="airsculpt-section bg-bgColor relative overflow-hidden" ref={sectionRef}>
      {/* Gradient overlay for visual effect */}
      <div className="absolute top-0 right-0 w-1/3 h-96 bg-primary/5 blur-[100px] rounded-full"></div>
      
      <div className="airsculpt-container">
        <motion.div 
          className="text-center mb-16"
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={fadeIn}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            About <span className="text-primary-gradient">Us</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-primary mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-white/70">
            Get to know the husband-and-wife team behind The Pixel Partners, combining technical expertise with creative vision.
          </p>
        </motion.div>
        
        <div className="flex flex-col lg:flex-row items-center gap-16">
          {/* Left Image Column */}
          <motion.div 
            className="lg:w-1/2 mb-10 lg:mb-0"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur-md transform -rotate-3"></div>
              
              {/* If we had a real image of Mark and Noelle, we'd use it here */}
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-1 rounded-2xl relative overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Mark and Noelle - The Pixel Partners" 
                  className="rounded-xl w-full h-auto z-10 relative" 
                />
                <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/70 to-transparent">
                  <p className="text-white font-semibold">Mark & Noelle</p>
                  <p className="text-white/70 text-sm">Founders, The Pixel Partners</p>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Right Content Column */}
          <motion.div 
            className="lg:w-1/2"
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            <motion.h3 
              className="text-2xl font-semibold mb-6 text-white"
              variants={fadeIn}
            >
              Hi, we're <span className="text-primary-gradient">Mark & Noelle</span>
            </motion.h3>
            
            <motion.p 
              className="text-white/70 mb-6"
              variants={fadeIn}
            >
              We're a dynamic husband-and-wife team behind The Pixel Partners with a shared passion for creating beautiful, functional websites that deliver results. With over 10 years of combined experience, we bring complementary skills to every project.
            </motion.p>
            
            <motion.p 
              className="text-white/70 mb-8"
              variants={fadeIn}
            >
              Mark leads our technical development with expertise in back-end systems and database architecture, while Noelle brings creative vision through her background in UX/UI design and front-end development. Together, we create seamless digital experiences that help our clients succeed online.
            </motion.p>
            
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10"
              variants={staggerContainer}
            >
              <motion.div className="flex items-start gap-3" variants={fadeIn}>
                <CheckCircle className="text-primary w-5 h-5 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-white">Web Design & UX</h4>
                  <p className="text-sm text-white/60">Intuitive, beautiful interfaces</p>
                </div>
              </motion.div>
              
              <motion.div className="flex items-start gap-3" variants={fadeIn}>
                <CheckCircle className="text-primary w-5 h-5 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-white">Front-End Development</h4>
                  <p className="text-sm text-white/60">Responsive, modern code</p>
                </div>
              </motion.div>
              
              <motion.div className="flex items-start gap-3" variants={fadeIn}>
                <CheckCircle className="text-primary w-5 h-5 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-white">Back-End Development</h4>
                  <p className="text-sm text-white/60">Robust, secure systems</p>
                </div>
              </motion.div>
              
              <motion.div className="flex items-start gap-3" variants={fadeIn}>
                <CheckCircle className="text-primary w-5 h-5 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-white">E-Commerce & CMS</h4>
                  <p className="text-sm text-white/60">Customized solutions</p>
                </div>
              </motion.div>
            </motion.div>
            
            <motion.a 
              href="#contact" 
              className="airsculpt-button-primary group flex items-center gap-2"
              onClick={(e) => { e.preventDefault(); handleButtonClick('#contact'); }}
              variants={fadeIn}
            >
              Let's Work Together 
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </motion.a>
          </motion.div>
        </div>
        

      </div>
    </section>
  );
}
