import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { SERVICES } from "@/lib/constants";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";

export default function Services() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-bgColor text-white">
      <Helmet>
        <title>Our Services | The Pixel Partners</title>
        <meta name="description" content="Explore our comprehensive web development and design services at The Pixel Partners." />
      </Helmet>
      
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <div className="relative bg-gradient-primary py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[url('/src/assets/grid-pattern.svg')] opacity-10"></div>
          <div className="absolute bottom-0 right-0 w-1/3 h-80 bg-accent/20 blur-[100px] rounded-full"></div>
          
          <div className="airsculpt-container relative z-10">
            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
              <p className="text-lg text-white/80 max-w-2xl mx-auto">
                Comprehensive web development and design solutions tailored to your unique business needs.
              </p>
            </motion.div>
          </div>
        </div>
        
        {/* Services List */}
        <div className="airsculpt-container py-20">
          <div className="grid grid-cols-1 gap-20">
            {SERVICES.map((service, index) => (
              <motion.div 
                key={index}
                className="flex flex-col md:flex-row gap-10 items-center"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                {/* Service Icon */}
                <div className="w-24 h-24 md:w-32 md:h-32 flex-shrink-0 rounded-full bg-gradient-primary flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                    <i className={`${service.icon} text-3xl text-white`}></i>
                  </div>
                </div>
                
                {/* Service Content */}
                <div className="flex-1">
                  <h2 className="text-2xl md:text-3xl font-bold mb-4">{service.title}</h2>
                  <div className="w-20 h-1 bg-accent mb-6"></div>
                  <p className="text-white/80 mb-6 max-w-2xl">{service.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <Check className="text-accent w-5 h-5 mt-1 flex-shrink-0" />
                        <span className="text-white/80">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    className="bg-gradient-accent hover:bg-accent/90 text-white font-medium"
                    onClick={() => {
                      setLocation(`/service/${index}`);
                      setTimeout(() => {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }, 50);
                    }}
                  >
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Call to Action */}
        <div className="bg-gradient-to-r from-primary to-primary-light py-16">
          <div className="airsculpt-container">
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-white/80 max-w-2xl mx-auto mb-8">
                Contact us today to discuss your project and learn how our services can help your business thrive online.
              </p>
              <Button 
                className="bg-white text-primary hover:bg-white/90 font-medium px-8 py-6"
                onClick={() => {
                  setLocation("/");
                  setTimeout(() => {
                    const contactSection = document.getElementById('contact');
                    if (contactSection) {
                      contactSection.scrollIntoView({ behavior: 'smooth' });
                    }
                  }, 50);
                }}
              >
                Contact Us
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}