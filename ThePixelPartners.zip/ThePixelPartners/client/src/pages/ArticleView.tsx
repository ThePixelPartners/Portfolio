import { useLocation, Link } from "wouter";
import { useEffect } from "react";
import { BLOG_POSTS } from "@/lib/constants";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft } from "lucide-react";

export default function ArticleView({ params }: { params: { id: string } }) {
  const [, setLocation] = useLocation();
  const articleId = parseInt(params.id);
  
  useEffect(() => {
    // If article exists, set the document title to the article title
    if (!isNaN(articleId) && articleId >= 0 && articleId < BLOG_POSTS.length) {
      const article = BLOG_POSTS[articleId];
      document.title = `${article.title} | The Pixel Partners`;
    } else {
      document.title = "Article Not Found | The Pixel Partners";
    }
    
    return () => {
      document.title = "The Pixel Partners | Web Design & Development";
    };
  }, [articleId]);
  
  // Check if article exists
  if (isNaN(articleId) || articleId < 0 || articleId >= BLOG_POSTS.length) {
    return (
      <div className="flex flex-col min-h-screen font-opensans bg-black text-white">
        <Navbar />
        <main className="flex-grow py-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-6 text-gradient">Article Not Found</h1>
          <p className="text-xl mb-8 text-gray-300">Sorry, the article you're looking for doesn't exist.</p>
          <Button 
            onClick={() => {
              setLocation("/articles");
              setTimeout(() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }, 50);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Articles
          </Button>
        </main>
        <Footer />
      </div>
    );
  }
  
  const article = BLOG_POSTS[articleId];
  
  return (
    <div className="flex flex-col min-h-screen font-opensans bg-black text-white">
      <Navbar />
      <main className="flex-grow pt-10 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="mb-6">
            <Button 
              variant="ghost" 
              className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/30 -ml-4"
              onClick={() => {
                setLocation("/articles");
                setTimeout(() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }, 50);
              }}
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Articles
            </Button>
          </div>
          
          <div className="h-96 rounded-xl overflow-hidden mb-8">
            <img 
              src={article.image} 
              alt={article.title} 
              className="w-full h-full object-cover"
            />
          </div>
          
          <Badge variant="outline" className="mb-4 bg-blue-900/30 border-blue-500/30 text-blue-400 px-3 py-1">
            {article.category}
          </Badge>
          
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-gradient">{article.title}</h1>
          
          <div className="flex items-center mb-8">
            <img 
              src={article.authorAvatar} 
              alt={article.author} 
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <p className="text-white font-medium">{article.author}</p>
              <p className="text-gray-400 text-sm">{article.date}</p>
            </div>
          </div>
          
          <div className="prose prose-lg prose-invert max-w-none">
            <p className="text-gray-300 mb-6 text-lg leading-relaxed">
              {article.excerpt}
            </p>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              In today's ever-evolving digital landscape, staying ahead requires embracing the latest technologies and design approaches. 
              This article explores key strategies that can transform your online presence and create meaningful user experiences.
            </p>
            
            <h2 className="text-2xl font-semibold text-white mt-10 mb-4">Why This Matters</h2>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              The digital experience is often the first interaction users have with your brand. Making it seamless, intuitive, and 
              memorable is crucial for establishing credibility and building relationships with your audience. Whether you're 
              developing a new website or enhancing an existing one, these principles can guide your approach.
            </p>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              At The Pixel Partners, we've implemented these strategies across diverse projects, consistently achieving 
              remarkable improvements in engagement, conversion, and overall user satisfaction. Our collaborative approach 
              ensures your unique brand voice remains central while leveraging proven techniques for maximum impact.
            </p>
            
            <h2 className="text-2xl font-semibold text-white mt-10 mb-4">Key Takeaways</h2>
            
            <ul className="list-disc pl-6 mb-8 text-gray-300 space-y-2">
              <li>Focus on user-centered design principles that prioritize intuitive navigation and clear information hierarchy</li>
              <li>Leverage modern technologies that balance visual appeal with performance and accessibility</li>
              <li>Implement data-driven decision making to continuously refine and optimize the user experience</li>
              <li>Maintain consistency across all touchpoints to strengthen brand recognition and trust</li>
            </ul>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              Ready to transform your digital presence? Let's collaborate to create exceptional web experiences that resonate 
              with your audience and drive meaningful results for your business.
            </p>
          </div>
          
          <div className="mt-12 pt-8 border-t border-gray-800">
            <h3 className="text-xl font-semibold mb-4 text-white">Continue Reading</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {BLOG_POSTS.filter((_, idx) => idx !== articleId).slice(0, 2).map((post, index) => (
                <div 
                  key={index} 
                  className="flex items-center p-4 rounded-lg bg-gray-900 border border-gray-800 cursor-pointer hover:border-blue-500/30 transition-all"
                  onClick={() => {
                    const nextId = BLOG_POSTS.findIndex(p => p.title === post.title);
                    setLocation(`/article/${nextId}`);
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >
                  <div className="w-16 h-16 rounded overflow-hidden mr-4">
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="text-white font-medium line-clamp-2">{post.title}</h4>
                    <p className="text-gray-400 text-sm">{post.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}