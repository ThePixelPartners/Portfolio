import { useEffect } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Services from "@/components/sections/Services";
import Blog from "@/components/sections/Blog";
import Contact from "@/components/sections/Contact";
import CTA from "@/components/sections/CTA";

export default function Home() {
  useEffect(() => {
    document.title = "The Pixel Partners | Web Design & Development";
    return () => {};
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen font-opensans text-gray-dark">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <About />
        <Services />
        <Blog />
        <Contact />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
