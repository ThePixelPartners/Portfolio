import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { BLOG_POSTS } from "@/lib/constants";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Articles() {
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    document.title = "The Newsroom | The Pixel Partners";
    return () => {
      document.title = "The Pixel Partners | Web Design & Development";
    };
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen font-opensans bg-black text-white">
      <Navbar />
      <main className="flex-grow py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="mb-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient">The Newsroom</h1>
          <p className="text-lg text-gray-300 max-w-3xl">
            Stay updated with our latest insights, tips, and industry trends in web development and digital design.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post, index) => (
            <div 
              key={index} 
              className="rounded-lg overflow-hidden flex flex-col bg-gray-900 border border-gray-800 shadow-xl hover:shadow-blue-900/20 transition-all transform hover:-translate-y-1 cursor-pointer"
              onClick={() => {
                setLocation(`/article/${index}`);
                setTimeout(() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }, 50);
              }}
            >
              <div 
                className="h-48 overflow-hidden cursor-pointer" 
                onClick={(e) => {
                  e.stopPropagation();
                  setLocation(`/article/${index}`);
                  setTimeout(() => {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }, 50);
                }}
              >
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <div className="p-6 flex-grow flex flex-col">
                <div className="flex items-center mb-4">
                  <Badge variant="outline" className="bg-blue-900/20 border-blue-500/30 text-blue-400">
                    {post.category}
                  </Badge>
                  <span className="ml-auto text-sm text-gray-400">{post.date}</span>
                </div>
                <h3 
                  className="text-xl font-semibold mb-3 text-white cursor-pointer hover:text-blue-400 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setLocation(`/article/${index}`);
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 50);
                  }}
                >{post.title}</h3>
                <p className="text-gray-400 mb-4 flex-grow">{post.excerpt}</p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center">
                    <img 
                      src={post.authorAvatar} 
                      alt={post.author} 
                      className="w-8 h-8 rounded-full mr-2"
                    />
                    <span className="text-sm text-gray-400">{post.author}</span>
                  </div>
                  <Button 
                    variant="link" 
                    className="text-blue-400 hover:text-blue-300"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/article/${index}`);
                      setTimeout(() => {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }, 50);
                    }}
                  >
                    Read More →
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <Button 
            variant="outline" 
            className="border-blue-500 text-blue-400 hover:bg-blue-900/30"
            onClick={() => {
              setLocation("/");
              setTimeout(() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }, 50);
            }}
          >
            ← Back to Home
          </Button>
        </div>
      </main>
      <Footer />
    </div>
  );
}