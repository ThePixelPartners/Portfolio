import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { SERVICES } from "@/lib/constants";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { ArrowLeft, ArrowRight, Check, Clock, Users, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";

// Additional content for each service
const SERVICE_DETAILS = [
  {
    // Web Design & UX/UI
    fullDescription: `Our Web Design & UX/UI service delivers stunning, user-focused digital experiences that captivate your audience and drive engagement. We blend aesthetic appeal with functional design to create websites that not only look impressive but also perform exceptionally well.

    At The Pixel Partners, we believe that great design is more than just visual appeal – it's about creating intuitive, seamless experiences that guide users naturally through your digital platform. Our approach combines creative design elements with strategic user experience principles to create websites that convert visitors into customers.`,
    benefits: [
      "Increase conversion rates with intuitive user journeys",
      "Establish brand credibility through professional design",
      "Reduce bounce rates with engaging interface elements",
      "Improve customer satisfaction with accessible designs"
    ],
    processSteps: [
      "Discovery and research to understand your users and business goals",
      "Wireframing and prototyping to test concepts before development",
      "Visual design that aligns with your brand identity",
      "User testing to validate design decisions",
      "Implementation with attention to responsive behavior"
    ],
    expertise: ["Adobe XD", "Figma", "Sketch", "InVision", "User Research", "Accessibility Standards"],
    image: "/src/assets/web-design-service.jpg",
    caseStudyTitle: "E-commerce Redesign Increases Conversions by 35%",
    caseStudyDesc: "We redesigned an outdated e-commerce platform with a focus on improving the purchase journey, resulting in a significant boost in conversion rates and customer satisfaction."
  },
  {
    // Front-End Development
    fullDescription: `Our Front-End Development service transforms designs into responsive, interactive, and high-performance websites that work flawlessly across all devices and browsers. We use cutting-edge technologies and best practices to ensure your website not only looks great but loads quickly and functions perfectly.

    The front-end of your website is what users directly interact with, making it crucial for creating positive first impressions. Our team of skilled developers crafts clean, efficient code that brings designs to life while ensuring optimal performance and accessibility.`,
    benefits: [
      "Faster loading times with optimized code",
      "Consistent experience across all devices and browsers",
      "Improved engagement with interactive elements",
      "Enhanced SEO through technical best practices"
    ],
    processSteps: [
      "Code architecture planning for maintainability",
      "Component-based development for efficiency",
      "Responsive implementation for all screen sizes",
      "Performance optimization for fast load times",
      "Comprehensive testing across browsers and devices"
    ],
    expertise: ["React", "Vue.js", "Angular", "TypeScript", "HTML5/CSS3", "SASS/LESS", "Webpack", "Next.js"],
    image: "/src/assets/frontend-service.jpg",
    caseStudyTitle: "Single Page Application Reduces Load Time by 60%",
    caseStudyDesc: "We rebuilt a content-heavy website as a React-based SPA, dramatically improving performance and user experience while maintaining full SEO benefits."
  },
  {
    // Back-End Development
    fullDescription: `Our Back-End Development service builds the robust foundation your web applications need to function reliably and securely. We create scalable server-side solutions that power your website's functionality, from database management to API integration and beyond.

    The back-end is the engine that drives your website's capabilities. Our development team designs and implements server-side systems that efficiently manage data, user authentication, and application logic while ensuring security and performance at scale.`,
    benefits: [
      "Scalable architecture that grows with your business",
      "Secure handling of sensitive user data",
      "Reliable performance even under heavy load",
      "Seamless integration with third-party services and APIs"
    ],
    processSteps: [
      "Database design and optimization for efficient data management",
      "API development for seamless front-end communication",
      "Security implementation to protect sensitive information",
      "Server configuration for optimal performance",
      "Thorough testing and quality assurance"
    ],
    expertise: ["Node.js", "PHP", "Python", "MySQL", "PostgreSQL", "MongoDB", "RESTful APIs", "GraphQL", "AWS/Azure"],
    image: "/src/assets/backend-service.jpg",
    caseStudyTitle: "Custom CRM System Improves Business Efficiency by 45%",
    caseStudyDesc: "We developed a tailor-made customer relationship management system that streamlined operations and provided valuable business intelligence through custom reporting."
  },
  {
    // E-Commerce & CMS
    fullDescription: `Our E-Commerce & CMS service helps businesses sell products and manage content effectively online. We create customized e-commerce solutions and content management systems that make it easy to update your website and grow your online business.

    Whether you're looking to launch a new online store or enhance your existing content management capabilities, our team provides tailored solutions that align with your specific business requirements and growth objectives.`,
    benefits: [
      "Simplified content and product management",
      "Optimized checkout process to increase sales",
      "Integrated payment and shipping solutions",
      "Customizable workflows for your business needs"
    ],
    processSteps: [
      "Platform selection based on your specific requirements",
      "Custom development for unique features and functionality",
      "Integration with payment gateways and shipping providers",
      "Implementation of inventory and order management systems",
      "Training and support for your team"
    ],
    expertise: ["Shopify", "WooCommerce", "WordPress", "Magento", "BigCommerce", "Strapi", "ContentfulCMS"],
    image: "/src/assets/ecommerce-service.jpg",
    caseStudyTitle: "Custom Shopify Solution Boosts Revenue by 70%",
    caseStudyDesc: "We developed a tailored Shopify implementation with custom features that significantly improved product discovery and streamlined the checkout process."
  }
];

export default function ServiceView({ params }: { params: { id: string } }) {
  const [, setLocation] = useLocation();
  const serviceId = parseInt(params.id);
  
  // Check if service exists
  if (isNaN(serviceId) || serviceId < 0 || serviceId >= SERVICES.length) {
    return (
      <div className="min-h-screen bg-bgColor text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Service Not Found</h1>
          <p className="mb-8">The service you're looking for doesn't exist.</p>
          <Button 
            onClick={() => setLocation("/services")}
            className="bg-gradient-accent hover:bg-accent/90"
          >
            View All Services
          </Button>
        </div>
      </div>
    );
  }
  
  const service = SERVICES[serviceId];
  const serviceDetail = SERVICE_DETAILS[serviceId];
  
  return (
    <div className="min-h-screen bg-bgColor text-white">
      <Helmet>
        <title>{service.title} | The Pixel Partners</title>
        <meta name="description" content={service.description} />
      </Helmet>
      
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <div className="relative bg-gradient-primary py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[url('/src/assets/grid-pattern.svg')] opacity-10"></div>
          <div className="absolute bottom-0 right-0 w-1/3 h-80 bg-accent/20 blur-[100px] rounded-full"></div>
          
          <div className="airsculpt-container relative z-10">
            <Button 
              variant="outline" 
              className="mb-8 border-white/20 text-white/80 hover:bg-white/10 hover:text-white"
              onClick={() => {
                setLocation("/services");
                setTimeout(() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }, 50);
              }}
            >
              <ArrowLeft className="mr-2 w-4 h-4" />
              Back to Services
            </Button>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6">{service.title}</h1>
              <div className="w-24 h-1 bg-accent mb-6"></div>
              <p className="text-lg text-white/80 max-w-2xl mb-6">
                {service.description}
              </p>
              <div className="flex flex-wrap gap-3">
                {service.features.map((feature, idx) => (
                  <span key={idx} className="bg-white/10 text-white/90 px-4 py-2 rounded-full text-sm">
                    {feature}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Service Details */}
        <div className="airsculpt-container py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold mb-6">How We Help</h2>
              <div className="prose prose-lg prose-invert max-w-none">
                <p className="text-white/80 whitespace-pre-line">{serviceDetail.fullDescription}</p>
              </div>
              
              <div className="mt-10">
                <h3 className="text-xl font-semibold mb-4">Key Benefits</h3>
                <ul className="space-y-3">
                  {serviceDetail.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="text-accent w-5 h-5 mt-1 flex-shrink-0" />
                      <span className="text-white/80">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
            
            <motion.div
              className="rounded-xl overflow-hidden aspect-video bg-gray-800 flex items-center justify-center"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="w-full h-full bg-gradient-to-tr from-primary to-primary-light opacity-90 flex items-center justify-center">
                <div className="text-center p-8">
                  <i className={`${service.icon} text-6xl text-white mb-6 block`}></i>
                  <h3 className="text-2xl font-bold mb-3">{serviceDetail.caseStudyTitle}</h3>
                  <p className="text-white/80">{serviceDetail.caseStudyDesc}</p>
                </div>
              </div>
            </motion.div>
          </div>
          
          {/* Process Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mb-20"
          >
            <h2 className="text-3xl font-bold mb-12 text-center">Our Process</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
              {serviceDetail.processSteps.map((step, idx) => (
                <div 
                  key={idx} 
                  className="relative bg-white/5 border border-white/10 rounded-lg p-6 text-center"
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center mx-auto mb-4">
                    <span className="font-bold">{idx + 1}</span>
                  </div>
                  <p className="text-white/80">{step}</p>
                  
                  {idx < serviceDetail.processSteps.length - 1 && (
                    <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                      <ArrowRight className="w-6 h-6 text-accent" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
          
          {/* Why Choose Us */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mb-20"
          >
            <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Us</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white/5 border border-white/10 rounded-lg p-8 text-center">
                <Clock className="w-12 h-12 text-accent mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Fast Turnaround</h3>
                <p className="text-white/80">We deliver quality results within your timeline, ensuring your project launches on schedule.</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-lg p-8 text-center">
                <Users className="w-12 h-12 text-accent mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Dedicated Team</h3>
                <p className="text-white/80">Work directly with our experienced husband-and-wife team for personalized attention.</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-lg p-8 text-center">
                <Award className="w-12 h-12 text-accent mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Quality Results</h3>
                <p className="text-white/80">We pride ourselves on delivering exceptional work that exceeds expectations.</p>
              </div>
            </div>
          </motion.div>
          
          {/* Technologies */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <h2 className="text-3xl font-bold mb-8 text-center">Technologies We Use</h2>
            <div className="flex flex-wrap justify-center gap-4">
              {serviceDetail.expertise.map((tech, idx) => (
                <div key={idx} className="bg-white/10 px-5 py-3 rounded-lg text-white/90">
                  {tech}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
        
        {/* Call to Action */}
        <div className="bg-gradient-to-r from-primary to-primary-light py-20">
          <div className="airsculpt-container">
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
              <p className="text-white/80 max-w-2xl mx-auto mb-10">
                Contact us today to discuss your {service.title.toLowerCase()} needs and how we can help your business succeed online.
              </p>
              <Button 
                className="bg-white text-primary hover:bg-white/90 font-medium px-8 py-6 text-lg"
                onClick={() => {
                  setLocation("/");
                  setTimeout(() => {
                    const contactSection = document.getElementById('contact');
                    if (contactSection) {
                      contactSection.scrollIntoView({ behavior: 'smooth' });
                    }
                  }, 50);
                }}
              >
                Get Started Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}