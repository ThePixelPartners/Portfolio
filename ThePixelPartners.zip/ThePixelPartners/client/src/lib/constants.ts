export const NAVIGATION_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '/services' },
  { label: 'The Newsroom', href: '/articles' },
  { label: 'Contact', href: '#contact' }
];

export const SERVICES = [
  {
    icon: 'fas fa-paint-brush',
    title: 'Web Design & UX/UI',
    description: 'Crafting intuitive user experiences and visually appealing interfaces that engage your audience.',
    features: [
      'Responsive design for all devices',
      'User-centered interface design',
      'Brand-aligned visual strategy'
    ]
  },
  {
    icon: 'fas fa-code',
    title: 'Front-End Development',
    description: 'Building responsive, cross-browser compatible websites with modern web technologies.',
    features: [
      'HTML5, CSS3, JavaScript expertise',
      'React, Vue & Angular development',
      'Performance optimization'
    ]
  },
  {
    icon: 'fas fa-server',
    title: 'Back-End Development',
    description: 'Creating secure, scalable, and efficient server-side applications for robust functionality.',
    features: [
      'PHP, Node.js, Python solutions',
      'Database design & optimization',
      'API development & integration'
    ]
  },
  {
    icon: 'fas fa-shopping-cart',
    title: 'E-Commerce & CMS',
    description: 'Customizing e-commerce platforms and content management systems to suit your business needs.',
    features: [
      'Shopify & WooCommerce stores',
      'WordPress customization',
      'Payment gateway integration'
    ]
  }
];

export const PORTFOLIO_ITEMS = [
  {
    title: 'Everlane',
    description: 'Sustainable fashion brand with transparent pricing and ethical manufacturing focus.',
    image: 'https://images.unsplash.com/photo-1607082350899-7e105aa886ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'ecommerce'
  },
  {
    title: 'TechVillage',
    description: 'Boutique electronics store with personalized service and curated selection of premium tech products.',
    image: 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'ecommerce'
  },
  {
    title: 'Horizon Financial Advisors',
    description: 'Boutique financial advisory firm offering personalized wealth management and retirement planning.',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    category: 'corporate'
  }
];

export const TESTIMONIALS = [
  {
    text: "The Pixel Partners transformed our outdated website into a modern, user-friendly platform that perfectly represents our brand. The increase in conversions has been remarkable!",
    name: "Emily Johnson",
    position: "Marketing Director, Everlane",
    avatar: "https://randomuser.me/api/portraits/women/45.jpg",
    rating: 5
  },
  {
    text: "Working with The Pixel Partners was a pleasure from start to finish. They took the time to understand our business needs and delivered a custom solution that exceeded our expectations.",
    name: "David Martinez",
    position: "Founder, Horizon Financial Advisors",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    rating: 5
  },
  {
    text: "The e-commerce platform The Pixel Partners built for us has transformed our business. Our online sales have increased by 150% in just six months, and the system is incredibly easy to manage.",
    name: "Sophia Chen",
    position: "Owner, TechVillage Electronics",
    avatar: "https://randomuser.me/api/portraits/women/68.jpg",
    rating: 5
  }
];

export const BLOG_POSTS = [
  {
    title: "Top Responsive Design Trends for 2025",
    excerpt: "From adaptive interfaces to AI-driven personalization, explore the cutting-edge responsive design approaches revolutionizing user experiences across all devices.",
    image: "https://images.unsplash.com/photo-1481487196290-c152efe083f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "Design",
    author: "Sarah",
    authorAvatar: "https://randomuser.me/api/portraits/women/32.jpg",
    date: "March 15, 2025"
  },
  {
    title: "Speed Matters: Optimizing Your Website Performance",
    excerpt: "Learn practical techniques to improve loading times, optimize resources, and create a seamless user experience that keeps visitors engaged.",
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "Development",
    author: "Michael",
    authorAvatar: "https://randomuser.me/api/portraits/men/32.jpg",
    date: "February 28, 2025"
  },
  {
    title: "5 UX Strategies to Boost E-Commerce Conversions",
    excerpt: "Discover proven user experience tactics that can significantly improve your online store's conversion rates and customer satisfaction.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    category: "E-Commerce",
    author: "Sarah",
    authorAvatar: "https://randomuser.me/api/portraits/women/32.jpg",
    date: "March 2, 2025"
  }
];
