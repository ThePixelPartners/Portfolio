// build-static.js
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define directories
const staticDir = path.join(__dirname, 'static');
const distDir = path.join(__dirname, 'dist');
const clientDir = path.join(__dirname, 'client');
const assetsDir = path.join(__dirname, 'attached_assets');

// Make sure we have a static directory
if (!fs.existsSync(staticDir)) {
  fs.mkdirSync(staticDir, { recursive: true });
}

console.log('Building the React application with Vite...');

// Run the normal build
try {
  execSync('npm run build', { stdio: 'inherit' });
  console.log('Vite build completed successfully.');
} catch (error) {
  console.error('Error during Vite build:', error);
  process.exit(1);
}

// Copy the build output to the static directory
try {
  if (fs.existsSync(path.join(distDir, 'public'))) {
    // Clean static directory first
    if (fs.existsSync(staticDir)) {
      fs.rmSync(staticDir, { recursive: true, force: true });
      fs.mkdirSync(staticDir);
    }
    
    // Copy files from dist/public to static
    copyDirectory(path.join(distDir, 'public'), staticDir);
    console.log('Build files copied to static directory successfully.');
  } else {
    console.error('Build output directory not found.');
    process.exit(1);
  }
} catch (error) {
  console.error('Error copying build files:', error);
  process.exit(1);
}

// Copy assets manually to ensure they're included
try {
  const assetsStaticDir = path.join(staticDir, 'assets');
  if (!fs.existsSync(assetsStaticDir)) {
    fs.mkdirSync(assetsStaticDir, { recursive: true });
  }
  
  if (fs.existsSync(assetsDir)) {
    copyDirectory(assetsDir, path.join(staticDir, 'assets'));
    console.log('Assets copied successfully.');
  }
} catch (error) {
  console.error('Error copying assets:', error);
}

// Create API stub for contact form to prevent 404 errors
try {
  const apiDir = path.join(staticDir, 'api');
  if (!fs.existsSync(apiDir)) {
    fs.mkdirSync(apiDir, { recursive: true });
  }
  
  // Create a static response for the contact form API
  const contactApiContent = JSON.stringify({
    message: 'Contact form submitted successfully',
    data: { name: '', email: '', subject: '', budget: '' }
  });
  
  fs.writeFileSync(path.join(apiDir, 'contact.json'), contactApiContent);
  console.log('Created API stubs for static deployment.');
} catch (error) {
  console.error('Error creating API stubs:', error);
}

// Create a simple .htaccess file for SPA routing
const htaccessContent = `
# Handle SPA routing
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
`;

fs.writeFileSync(path.join(staticDir, '.htaccess'), htaccessContent);
console.log('Created .htaccess file for SPA routing.');

// Create a netlify config file for SPA routing
const netlifyConfig = `
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`;

fs.writeFileSync(path.join(staticDir, '_redirects'), '/* /index.html 200');
fs.writeFileSync(path.join(staticDir, 'netlify.toml'), netlifyConfig);
console.log('Created Netlify configuration for SPA routing.');

console.log('\nStatic build complete! Files are available in the "static" directory.');
console.log('You can deploy these files to any static hosting service like Netlify, Vercel, or GitHub Pages.');

// Helper function to recursively copy a directory
function copyDirectory(source, destination) {
  // Create the destination directory if it doesn't exist
  if (!fs.existsSync(destination)) {
    fs.mkdirSync(destination, { recursive: true });
  }

  // Get all files and subdirectories in the source directory
  const entries = fs.readdirSync(source, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(source, entry.name);
    const destPath = path.join(destination, entry.name);

    if (entry.isDirectory()) {
      // Recursively copy subdirectories
      copyDirectory(srcPath, destPath);
    } else {
      // Copy files
      fs.copyFileSync(srcPath, destPath);
    }
  }
}