# Static Deployment Instructions

This project can be built as a fully static website that can be deployed to any static hosting service like Netlify, Vercel, GitHub Pages, or traditional web hosting.

## Building the Static Website

### Option 1: Using the convenience script

Simply run the build and package script:

```bash
./build-and-package.sh
```

This will:
1. Build the React application
2. Generate all necessary static files
3. Create a zip archive for easy deployment

### Option 2: Manual build

If you prefer to do it manually, you can run:

```bash
node build-static.js
```

This will generate all the static files in the `static` directory.

## Deployment Options

### Option 1: Netlify

1. Sign up or log in to [Netlify](https://www.netlify.com/)
2. From your Netlify dashboard, drag and drop the `static` folder onto the deployment area
3. Netlify will automatically detect the `netlify.toml` file and configure routing for the SPA

### Option 2: Vercel

1. Sign up or log in to [Vercel](https://vercel.com/)
2. Install the Vercel CLI: `npm i -g vercel`
3. Navigate to the `static` directory in your terminal and run: `vercel`
4. Follow the prompts to complete the deployment

### Option 3: Traditional Web Hosting (cPanel, etc.)

1. Upload all files in the `static` directory to your web hosting using FTP or the hosting control panel
2. Make sure the `.htaccess` file is included in the upload (it's used for SPA routing)
3. Ensure your hosting supports .htaccess configurations

### Option 4: GitHub Pages

1. Create a new repository on GitHub
2. Push all files in the `static` directory to your repository
3. Go to repository Settings > Pages and enable GitHub Pages
4. Create a file named `404.html` that is identical to `index.html` to support SPA routing

## Contact Form Configuration

The contact form in this static build uses a client-side implementation that simulates form submission. In a production environment, you should replace it with a real form submission service:

- **Netlify Forms**: If deploying to Netlify, update the form with `data-netlify="true"` attribute
- **Formspree**: Update the form action to point to your Formspree endpoint
- **Custom API**: Set up a serverless function or backend API to receive form submissions

## Files and Directory Structure

- `static/` - Contains all the static files for deployment
  - `index.html` - The main HTML file
  - `assets/` - Contains JavaScript, CSS, and image assets
  - `api/` - Contains API stubs for the static deployment
  - `.htaccess` - Apache configuration for SPA routing
  - `_redirects` - Netlify redirects configuration
  - `netlify.toml` - Netlify configuration file
  - `README.html` - Browser-viewable deployment instructions

## Need Help?

For assistance with deployment or custom modifications, contact The Pixel Partners at hello@thepixelpartners.com.