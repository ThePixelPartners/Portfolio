import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for contact form submissions
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, subject, budget, message } = req.body;
      
      // Validate required fields
      if (!name || !email || !message) {
        return res.status(400).json({ message: 'Name, email, and message are required' });
      }
      
      // In a real app, you would store this in a database or send an email
      // For now, we'll just log it and return a success response
      console.log('Contact form submission:', { name, email, subject, budget, message });
      
      return res.status(200).json({ 
        message: 'Contact form submitted successfully',
        data: { name, email, subject, budget }
      });
    } catch (error) {
      console.error('Error processing contact form:', error);
      return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
